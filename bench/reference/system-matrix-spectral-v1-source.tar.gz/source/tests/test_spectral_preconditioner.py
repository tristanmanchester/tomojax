"""Independent dense Fourier references for the internal normal preconditioner."""

from __future__ import annotations

import math

import jax
import jax.numpy as jnp
import numpy as np
import pytest

from tomojax.core.preconditioning import apply_spectral_inverse, estimate_normal_spectrum


@pytest.mark.parametrize("shape", [(3, 2, 5), (2, 3, 4)])
def test_adjoint_power_spectrum_matches_independent_unitary_fourier_diagonal(shape):
    rng = np.random.default_rng(815)
    n = math.prod(shape)
    matrix = rng.normal(size=(43, n)).astype(np.float32)
    seed, count, shift = 31, 8, 0.13
    a = jnp.asarray(matrix)

    def adjoint(y):
        return (a.T @ y).reshape(shape)

    actual = jax.jit(
        lambda: estimate_normal_spectrum(
            adjoint, (43,), shape, probes=count, seed=seed, diagonal_shift=shift
        )
    )()
    # Build the complex DFT explicitly, independent of the implementation's FFT.
    coordinates = np.indices(shape).reshape(3, -1).T
    f = np.exp(-2j * np.pi * (coordinates / shape) @ coordinates.T) / np.sqrt(n)
    probes = np.stack(
        [
            np.asarray(jax.random.rademacher(jax.random.fold_in(jax.random.key(seed), i), (43,)))
            for i in range(count)
        ]
    )
    transformed = f @ matrix.astype(float).T @ probes.T
    expected = (np.mean(abs(transformed) ** 2, axis=1) + shift).reshape(shape)
    np.testing.assert_allclose(actual, expected[..., : shape[-1] // 2 + 1], rtol=2e-6)

    spectrum = np.asarray(actual)
    inverse_columns = np.column_stack(
        [
            np.asarray(apply_spectral_inverse(jnp.asarray(v.reshape(shape)), actual)).ravel()
            for v in np.eye(n, dtype=np.float32)
        ]
    )
    np.testing.assert_allclose(inverse_columns, inverse_columns.T, atol=2e-8)
    assert np.linalg.eigvalsh(inverse_columns).min() > 0
    np.testing.assert_allclose(inverse_columns @ np.ones(n), 1 / spectrum.flat[0], rtol=2e-6)


def test_spectral_inverse_preserves_real_shape_and_identity_for_zero_operator():
    shape = (3, 4, 5)
    spectrum = estimate_normal_spectrum(lambda _: jnp.zeros(shape), (11,), shape)
    x = jnp.asarray(np.random.default_rng(51).normal(size=shape), jnp.float32)
    result = apply_spectral_inverse(x, spectrum)
    assert result.shape == shape
    np.testing.assert_allclose(result, x, atol=4e-7)
    shifted = estimate_normal_spectrum(
        lambda _: jnp.zeros(shape), (11,), shape, diagonal_shift=0.25
    )
    np.testing.assert_allclose(apply_spectral_inverse(x, shifted), 4 * x, atol=2e-6)


def test_spectral_preconditioner_rejects_invalid_inputs_and_preserves_nonfinite_failure():
    for kwargs in ({"probes": 0}, {"probes": 1.5}, {"diagonal_shift": -1}):
        with pytest.raises(ValueError):
            estimate_normal_spectrum(lambda _: jnp.ones((2, 3, 4)), (7,), (2, 3, 4), **kwargs)
    with pytest.raises(ValueError, match="real volume shape"):
        estimate_normal_spectrum(lambda _: jnp.ones((2, 3, 5)), (7,), (2, 3, 4))
    result = estimate_normal_spectrum(lambda _: jnp.full((2, 3, 4), jnp.nan), (7,), (2, 3, 4))
    assert not np.isfinite(result).all()
