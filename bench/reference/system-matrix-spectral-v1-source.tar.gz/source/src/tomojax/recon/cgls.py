"""Conjugate-gradient least-squares reconstruction with matched FP32 operators."""

from __future__ import annotations

from dataclasses import dataclass, field
from functools import partial
import math
import operator
from typing import TYPE_CHECKING, Literal, NamedTuple

import jax
import jax.numpy as jnp
import numpy as np

from tomojax.core.geometry.views import stack_view_poses
from tomojax.core.preconditioning import apply_spectral_inverse, estimate_normal_spectrum
from tomojax.core.projector import forward_project_view_T, sum_backproject_views_T
from tomojax.core.validation import (
    validate_detector_grid,
    validate_grid,
    validate_pose_stack,
    validate_projection_stack,
    validate_volume,
)
from tomojax.recon._quadratic import gradient_energy, gradient_normal, regularization_normal

if TYPE_CHECKING:
    from collections.abc import Callable

    from tomojax.geometry import Detector, Geometry, Grid


@dataclass(frozen=True)
class CGLSConfig:
    """Control an unconstrained least-squares solve.

    Minimize ``||A x - y||² + damping² ||x||² + gradient_damping² ||D x||²``
    using the discrete matched
    adjoint. Stop when the normal-residual norm falls below
    ``atol + rtol * initial_normal_residual_norm`` or after ``iters`` updates.
    ``roundoff_limit`` indicates voxelwise update stagnation or a normal gradient
    within an FP32 cancellation estimate, without claiming the requested tolerance.
    Before reporting convergence or roundoff, recompute the data and normal
    residuals. A premature convergence indication from recursive residual drift
    restarts the conjugate direction. Periodic checks near the FP32 noise floor
    also catch recurrences kept moving by nondeterministic atomic reductions.
    This criterion measures stationarity, not reconstruction quality. No
    positivity clipping or TV regularization is applied. ``auto`` uses Pallas
    on CUDA with a canonical detector grid, otherwise JAX. An explicit Pallas
    request must be supported and never silently falls back.

    ``D`` takes adjacent voxel differences divided by physical voxel spacing,
    with no edges outside the volume. ``gradient_damping`` adds quadratic
    smoothness; it does not impose positivity or penalize a constant volume.
    Both penalties default to zero. Their weights are independent of view count;
    the data term is an unnormalized sum of squared residuals.

    ``projector_model="ray"`` retains the existing trilinear ray marcher.
    ``"joseph"`` samples voxel-centre planes along the dominant voxel direction,
    interpolates each plane and uses its matched transpose. Bilinear interpolation
    is the default; ``joseph_interpolation="cubic"`` selects Keys cubic convolution
    with a=-1/2 and a 4-by-4 stencil, including negative weights. On CUDA
    that transpose gathers into voxels without atomic writes. This is a different
    discretization, selected explicitly; only canonical detector grids are supported.

    Experimental ``preconditioner="spectral"`` estimates a positive Fourier
    normal diagonal with eight deterministic data-space adjoint probes. Its
    setup and each FFT application cost time and memory; no workflow speedup
    is assumed. It changes the search directions, not the least-squares problem
    or the unpreconditioned residual used for stopping. The default is ``none``.
    """

    iters: int = 50
    rtol: float = 1e-6
    atol: float = 0.0
    damping: float = 0.0
    views_per_batch: int = 64
    projector_backend: Literal["auto", "jax", "pallas"] = "auto"
    projector_model: Literal["ray", "joseph"] = "ray"
    joseph_interpolation: Literal["linear", "cubic"] = "linear"
    gradient_damping: float = 0.0
    preconditioner: Literal["none", "spectral"] = field(default="none", kw_only=True)


class _State(NamedTuple):
    iteration: jax.Array
    x: jax.Array
    residual: jax.Array
    direction: jax.Array
    gamma: jax.Array
    preconditioned_gamma: jax.Array
    failed: jax.Array
    roundoff: jax.Array
    residual_verified: jax.Array
    residual_recomputations: jax.Array


def _validate_model(cfg: CGLSConfig, det_grid: object) -> None:
    if cfg.projector_model not in {"ray", "joseph"}:
        raise ValueError("cgls: projector_model must be 'ray' or 'joseph'")
    if cfg.joseph_interpolation not in {"linear", "cubic"}:
        raise ValueError("cgls: joseph_interpolation must be 'linear' or 'cubic'")
    if cfg.joseph_interpolation != "linear" and cfg.projector_model != "joseph":
        raise ValueError("cgls: cubic interpolation requires projector_model='joseph'")
    if cfg.projector_model == "joseph" and det_grid is not None:
        raise ValueError("cgls: Joseph sampling requires the canonical detector grid")


def _operators(
    poses: jax.Array,
    grid: Grid,
    detector: Detector,
    det_grid: tuple[jax.Array, jax.Array] | None,
    backend: str,
    batch_size: int,
    model: str = "ray",
    joseph_interpolation: str = "linear",
    absolute_weights: bool = False,
) -> tuple[Callable[[jax.Array], jax.Array], Callable[[jax.Array], jax.Array]]:
    n = int(poses.shape[0])
    batch_size = min(batch_size, n)
    chunks = (n + batch_size - 1) // batch_size
    if model == "joseph":
        from tomojax.core.joseph import (
            forward_project_planes,
            plane_coefficients,
            sum_backproject_planes,
        )

        coefficients = plane_coefficients(poses, grid, detector)

    def select(chunk: jax.Array) -> tuple[jax.Array, jax.Array, jax.Array]:
        start = jnp.minimum(chunk * batch_size, n - batch_size)
        batch = jax.lax.dynamic_slice(poses, (start, 0, 0), (batch_size, 4, 4))
        # The final shifted batch overlaps earlier views. Its adjoint must count
        # only new views; forward writes the same overlapping values again.
        valid = start + jnp.arange(batch_size) >= chunk * batch_size
        return start, batch, valid

    def forward(volume: jax.Array) -> jax.Array:
        def body(chunk: jax.Array, output: jax.Array) -> jax.Array:
            start, batch, _ = select(chunk)
            if model == "joseph":
                coeff = jax.lax.dynamic_slice(coefficients, (start, 0), (batch_size, 14))
                projected = forward_project_planes(
                    coeff,
                    volume,
                    grid,
                    detector,
                    backend=backend,
                    interpolation=joseph_interpolation,
                )
            elif backend == "pallas":
                from tomojax.core.pallas.api import (
                    PallasProjectorOptions,
                    forward_project_views_T_pallas,
                )

                projected = forward_project_views_T_pallas(
                    batch,
                    grid,
                    detector,
                    volume,
                    options=PallasProjectorOptions(tile_shape=(16, 4), num_warps=1),
                )
            else:
                projected = jax.vmap(
                    lambda t: forward_project_view_T(t, grid, detector, volume, det_grid=det_grid)
                )(batch)
            return jax.lax.dynamic_update_slice(output, projected, (start, 0, 0))

        return jax.lax.fori_loop(
            0, chunks, body, jnp.zeros((n, detector.nv, detector.nu), dtype=jnp.float32)
        )

    def adjoint(images: jax.Array) -> jax.Array:
        def body(chunk: jax.Array, output: jax.Array) -> jax.Array:
            start, batch, valid = select(chunk)
            data = jax.lax.dynamic_slice(
                images, (start, 0, 0), (batch_size, detector.nv, detector.nu)
            )
            data = jnp.where(valid[:, None, None], data, 0.0)
            if model == "joseph":
                coeff = jax.lax.dynamic_slice(coefficients, (start, 0), (batch_size, 14))
                update = sum_backproject_planes(
                    coeff,
                    data,
                    grid,
                    detector,
                    backend=backend,
                    interpolation=joseph_interpolation,
                    absolute_weights=absolute_weights,
                )
            elif backend == "pallas":
                from tomojax.core.pallas.api import sum_backproject_views_T_pallas

                update = sum_backproject_views_T_pallas(
                    batch, grid, detector, data, tile_shape=(16, 4), num_warps=1
                )
            else:
                update = sum_backproject_views_T(batch, grid, detector, data, det_grid=det_grid)
            return output + update

        return jax.lax.fori_loop(
            0, chunks, body, jnp.zeros((grid.nx, grid.ny, grid.nz), dtype=jnp.float32)
        )

    return forward, adjoint


def _spectral_inverse(
    adjoint: Callable[[jax.Array], jax.Array],
    data_shape: tuple[int, ...],
    shape: tuple[int, int, int],
    spacing: tuple[float, float, float],
    damp2: jax.Array,
    gradient_damping: jax.Array | None,
    needed: jax.Array,
) -> Callable[[jax.Array], jax.Array]:
    spectral_shape = (*shape[:-1], shape[-1] // 2 + 1)

    def setup_spectrum() -> jax.Array:
        spectrum = estimate_normal_spectrum(adjoint, data_shape, shape, diagonal_shift=damp2)
        if gradient_damping is not None:
            # Exact Fourier diagonal of the free-boundary edge penalty:
            # each axis has N-1 edges, not the N edges of a periodic grid.
            for axis, (size, pitch) in enumerate(zip(shape, spacing, strict=True)):
                frequencies = jnp.arange(spectral_shape[axis], dtype=jnp.float32)
                term = 4 * (1 - 1 / size) * jnp.sin(jnp.pi * frequencies / size) ** 2 / pitch**2
                broadcast = [1, 1, 1]
                broadcast[axis] = spectral_shape[axis]
                spectrum = spectrum + gradient_damping**2 * term.reshape(broadcast)
        return spectrum

    spectrum = jax.lax.cond(needed, setup_spectrum, lambda: jnp.ones(spectral_shape, jnp.float32))
    return partial(apply_spectral_inverse, spectrum=spectrum)


@partial(
    jax.jit,
    static_argnames=(
        "grid",
        "detector",
        "backend",
        "batch_size",
        "zero_start",
        "model",
        "joseph_interpolation",
        "preconditioner",
    ),
)
def _solve(  # noqa: PLR0915 - keep residual verification with the CGLS recurrence
    poses: jax.Array,
    data: jax.Array,
    initial: jax.Array,
    det_grid: tuple[jax.Array, jax.Array] | None,
    max_iters: jax.Array,
    rtol: jax.Array,
    atol: jax.Array,
    damping: jax.Array,
    *,
    grid: Grid,
    detector: Detector,
    backend: str,
    batch_size: int,
    zero_start: bool,
    model: str = "ray",
    joseph_interpolation: str = "linear",
    gradient_damping: jax.Array | None = None,
    preconditioner: str = "none",
) -> tuple[_State, jax.Array, jax.Array]:
    # Iteration budgets and changing data/poses are dynamic: budget sweeps and
    # repeated scans reuse the same compiled executable.
    forward, adjoint = _operators(
        poses, grid, detector, det_grid, backend, batch_size, model, joseph_interpolation
    )
    magnitude_adjoint = adjoint
    if model == "joseph" and joseph_interpolation == "cubic":
        # Cubic convolution has negative lobes. A.T @ abs(residual) is not
        # a cancellation bound: the roundoff estimate needs abs(A).T instead.
        _, magnitude_adjoint = _operators(
            poses,
            grid,
            detector,
            det_grid,
            backend,
            batch_size,
            model,
            joseph_interpolation,
            absolute_weights=True,
        )
    residual = data if zero_start else data - forward(initial)
    damp2 = damping * damping
    spacing = (grid.vx, grid.vy, grid.vz)

    penalty_gradient = partial(
        regularization_normal,
        spacing=spacing,
        damping=damping,
        gradient_damping=gradient_damping,
    )

    gradient = adjoint(residual) - penalty_gradient(initial)
    gamma = jnp.sum(gradient * gradient)
    threshold = atol + rtol * jnp.sqrt(gamma)

    precondition = (
        _spectral_inverse(
            adjoint,
            data.shape,
            initial.shape,
            spacing,
            damp2,
            gradient_damping,
            (max_iters > 0) & (gamma > threshold * threshold),
        )
        if preconditioner == "spectral"
        else lambda value: value
    )

    preconditioned = precondition(gradient)
    rho = jnp.vdot(gradient, preconditioned).real if preconditioner == "spectral" else gamma
    state = _State(
        jnp.int32(0),
        initial,
        residual,
        preconditioned,
        gamma,
        rho,
        ~jnp.isfinite(gamma) | ~jnp.isfinite(rho) | ((gamma > 0) & (rho <= 0)),
        jnp.bool_(False),
        jnp.bool_(True),
        jnp.int32(0),
    )

    def condition(state: _State) -> jax.Array:
        return (
            (state.iteration < max_iters)
            & (state.gamma > threshold * threshold)
            & ~state.failed
            & ~state.roundoff
        )

    def step(state: _State) -> _State:
        projected = forward(state.direction)
        direction_norm2 = jnp.sum(state.direction**2)
        denominator = jnp.sum(projected * projected) + damp2 * direction_norm2
        if gradient_damping is not None:
            denominator = denominator + gradient_damping**2 * gradient_energy(
                state.direction, spacing
            )
        valid = jnp.isfinite(denominator) & (denominator > 0)
        alpha = state.preconditioned_gamma / jnp.where(valid, denominator, 1.0)
        x = state.x + alpha * state.direction
        residual = state.residual - alpha * projected
        gradient = adjoint(residual) - penalty_gradient(x)
        gamma_new = jnp.sum(gradient * gradient)
        valid &= jnp.isfinite(gamma_new)
        # A requested normal-residual tolerance can lie below attainable FP32
        # accuracy, especially for inconsistent damped systems. Continuing a
        # conjugate recurrence below roundoff can amplify arithmetic noise.
        # Check each voxel: a global volume norm can hide meaningful updates
        # to weak regions when another region contains much larger values.
        # Report this separately; do not silently relax the requested tolerance.
        roundoff = jnp.all(
            jnp.abs(alpha * state.direction)
            <= jnp.finfo(jnp.float32).eps * jnp.maximum(jnp.abs(x), jnp.finfo(jnp.float32).tiny)
        )
        small_global_update = alpha * alpha * direction_norm2 <= jnp.finfo(
            jnp.float32
        ).eps ** 2 * jnp.sum(x * x)
        convergence_candidate = gamma_new <= threshold * threshold
        # Atomic transpose reductions can keep a noisy conjugate recurrence
        # moving even after it reaches the FP32 cancellation floor. Check the
        # true residual periodically once its norm is small, before that noise
        # gets amplified. This does not relax the requested stopping tolerance.
        near_precision = gamma_new <= jnp.finfo(jnp.float32).eps * gamma
        periodic_check = ((state.iteration + 1) % 16 == 0) & near_precision
        verify = roundoff | small_global_update | convergence_candidate | periodic_check

        def recompute() -> tuple[jax.Array, jax.Array, jax.Array, jax.Array, jax.Array]:
            prediction = forward(x)
            exact_residual = data - prediction
            exact_gradient = adjoint(exact_residual) - penalty_gradient(x)
            exact_gamma = jnp.sum(exact_gradient * exact_gradient)
            # A componentwise cancellation estimate keeps a bright, already
            # solved region from setting another region's precision limit.
            # It is an FP32 stagnation diagnostic, never a relaxed tolerance.
            cancellation = magnitude_adjoint(jnp.abs(data) + jnp.abs(prediction)) + damp2 * jnp.abs(
                x
            )
            if gradient_damping is not None:
                cancellation = cancellation + gradient_damping**2 * gradient_normal(
                    jnp.abs(x), spacing, absolute_weights=True
                )
            at_precision = jnp.all(
                jnp.abs(exact_gradient) <= 8 * jnp.finfo(jnp.float32).eps * cancellation
            )
            gap2 = jnp.sum((exact_gradient - gradient) ** 2)
            replace = convergence_candidate | roundoff | at_precision | (gap2 > 0.01 * gamma_new)
            return (
                jnp.where(replace, exact_residual, residual),
                jnp.where(replace, exact_gradient, gradient),
                jnp.where(replace, exact_gamma, gamma_new),
                replace,
                roundoff | at_precision,
            )

        residual, gradient, gamma_new, replaced, roundoff = jax.lax.cond(
            verify, recompute, lambda: (residual, gradient, gamma_new, jnp.bool_(False), roundoff)
        )
        valid &= jnp.isfinite(gamma_new)
        preconditioned = precondition(gradient)
        rho_new = (
            jnp.vdot(gradient, preconditioned).real if preconditioner == "spectral" else gamma_new
        )
        valid &= jnp.isfinite(rho_new) & ((gamma_new == 0) | (rho_new > 0))
        # A replaced residual invalidates the old conjugate recurrence. If the
        # recomputed norm fails the tolerance, continue with a fresh direction.
        direction = jnp.where(
            replaced,
            preconditioned,
            preconditioned + (rho_new / state.preconditioned_gamma) * state.direction,
        )
        next_state = _State(
            state.iteration + 1,
            x,
            residual,
            direction,
            gamma_new,
            rho_new,
            jnp.bool_(False),
            roundoff,
            replaced,
            state.residual_recomputations + verify.astype(jnp.int32),
        )
        # Do not replace a finite iterate with a broken one at rank breakdown.
        return jax.lax.cond(
            valid, lambda: next_state, lambda: state._replace(failed=jnp.bool_(True))
        )

    result = jax.lax.while_loop(condition, step, state)
    return result, jnp.sqrt(gamma), threshold


def cgls(
    geometry: Geometry,
    grid: Grid,
    detector: Detector,
    projections: jnp.ndarray,
    *,
    init_x: jnp.ndarray | None = None,
    config: CGLSConfig | None = None,
    det_grid: tuple[jnp.ndarray, jnp.ndarray] | None = None,
) -> tuple[jnp.ndarray, dict[str, object]]:
    """Reconstruct with CGLS and return volume plus convergence diagnostics.

    Inputs and the solve use FP32. The method supports arbitrary posed parallel
    rays, anisotropic voxels, detector offsets, and JAX explicit detector grids.
    It avoids operator-norm estimation and stores a constant number of volumes
    and sinograms, independent of iteration count. This public solver returns
    host diagnostics and is not a differentiable reconstruction layer.
    """
    cfg = CGLSConfig() if config is None else config
    iterations, batch = operator.index(cfg.iters), operator.index(cfg.views_per_batch)
    if iterations < 0 or batch < 1:
        raise ValueError("cgls: iters must be nonnegative and views_per_batch must be positive")
    for name in ("rtol", "atol", "damping", "gradient_damping"):
        value = float(getattr(cfg, name))
        if not math.isfinite(value) or value < 0:
            raise ValueError(f"cgls: {name} must be finite and nonnegative")
    if cfg.projector_backend not in {"auto", "jax", "pallas"}:
        raise ValueError("cgls: projector_backend must be 'auto', 'jax' or 'pallas'")
    if cfg.preconditioner not in {"none", "spectral"}:
        raise ValueError("cgls: preconditioner must be 'none' or 'spectral'")
    _validate_model(cfg, det_grid)
    shape = validate_grid(grid, "cgls grid")
    n, _, _ = validate_projection_stack(projections, detector, geometry=geometry, context="cgls")
    validate_detector_grid(det_grid, detector, context="cgls")
    if init_x is not None:
        validate_volume(init_x, grid, context="cgls", name="init_x")
    data = jnp.asarray(projections, dtype=jnp.float32)
    initial = (
        jnp.zeros(shape, dtype=jnp.float32)
        if init_x is None
        else jnp.asarray(init_x, dtype=jnp.float32)
    )
    poses = stack_view_poses(geometry, n)
    validate_pose_stack(poses, n, context="cgls")
    if not bool(
        jnp.all(jnp.isfinite(data)) & jnp.all(jnp.isfinite(initial)) & jnp.all(jnp.isfinite(poses))
    ):
        raise ValueError("cgls: projections, initial volume and poses must be finite")
    if cfg.projector_model == "joseph":
        from tomojax.core.joseph import validate_plane_geometry

        validate_plane_geometry(poses, grid, detector)
    cuda = (
        jax.default_backend() == "gpu"
        and "cuda" in jax.devices()[0].client.platform_version.lower()
    )
    backend = cfg.projector_backend
    if backend == "auto":
        backend = "pallas" if cuda and det_grid is None else "jax"
    if backend == "pallas" and (not cuda or det_grid is not None):
        raise ValueError("cgls: Pallas requires CUDA and the canonical detector grid")
    result, initial_norm, threshold = _solve(
        poses,
        data,
        initial,
        det_grid,
        jnp.int32(iterations),
        jnp.float32(cfg.rtol),
        jnp.float32(cfg.atol),
        jnp.float32(cfg.damping),
        grid=grid,
        detector=detector,
        backend=backend,
        batch_size=batch,
        zero_start=init_x is None,
        model=cfg.projector_model,
        joseph_interpolation=cfg.joseph_interpolation,
        gradient_damping=jnp.float32(cfg.gradient_damping) if cfg.gradient_damping else None,
        preconditioner=cfg.preconditioner,
    )
    count, gamma, failed, roundoff, first_norm, tolerance, verified, recomputations = (
        jax.device_get(
            (
                result.iteration,
                result.gamma,
                result.failed,
                result.roundoff,
                initial_norm,
                threshold,
                result.residual_verified,
                result.residual_recomputations,
            )
        )
    )
    converged = bool(not failed and gamma <= tolerance * tolerance)
    info = {
        "effective_iters": int(count),
        "converged": converged,
        "termination": "numerical_breakdown"
        if failed
        else "converged"
        if converged
        else "roundoff_limit"
        if roundoff
        else "iteration_limit",
        "normal_residual_norm": float(np.sqrt(gamma)),
        "normal_residual_is_recomputed": bool(verified),
        "residual_recomputations": int(recomputations),
        "initial_normal_residual_norm": float(first_norm),
        "normal_residual_tolerance": float(tolerance),
        "projector_backend": backend,
        "projector_model": cfg.projector_model,
        "joseph_interpolation": cfg.joseph_interpolation
        if cfg.projector_model == "joseph"
        else None,
        "views_per_batch": min(batch, n),
        "damping": float(cfg.damping),
        "gradient_damping": float(cfg.gradient_damping),
        "preconditioner": cfg.preconditioner,
        "preconditioner_probes": 8
        if cfg.preconditioner == "spectral" and iterations > 0 and first_norm > tolerance
        else 0,
    }
    return result.x, info
