"""Experimental positive Fourier preconditioners with bounded probe storage.

For a real data-space random vector with E[zz.T] = I, E[|F A.T z|²] is
diag(F A.T A F*), where F is the unitary Fourier transform. Averaging powers
keeps the estimate nonnegative without assuming that one impulse response is
translation invariant. This approximates a normal operator; it never replaces
the forward model or its matched transpose in the solved system.
"""

from __future__ import annotations

import math
from typing import TYPE_CHECKING

import jax
import jax.numpy as jnp

if TYPE_CHECKING:
    from collections.abc import Callable


def estimate_normal_spectrum(
    adjoint: Callable[[jax.Array], jax.Array],
    data_shape: tuple[int, ...],
    volume_shape: tuple[int, int, int],
    *,
    probes: int = 8,
    seed: int = 0,
    diagonal_shift: float | jax.Array = 0.0,
) -> jax.Array:
    """Estimate the Fourier diagonal of ``A.T A + diagonal_shift I``.

    ``adjoint`` must be a real FP32 matched transpose, including any fixed data
    weights. Eight deterministic Rademacher probes are streamed by default;
    no probe-by-volume stack is retained. The shift is a *normal-matrix* shift,
    not its square root. A relative FP32 floor bounds the inverse even for a
    rank-deficient operator. An all-zero operator receives an identity inverse.
    Nonfinite operator output remains visible instead of being repaired.

    Setup costs one adjoint and one FFT per probe. Both setup and applications
    must be included in workflow timings; iteration savings alone do not imply
    a speed improvement. The caller must keep the preconditioner fixed during
    a CG solve and project both sides when restricting to an active subspace.
    """
    if probes < 1 or int(probes) != probes:
        raise ValueError("spectral preconditioner requires a positive integer probe count")
    if len(volume_shape) != 3 or min(volume_shape) < 1 or not data_shape or min(data_shape) < 1:
        raise ValueError("spectral preconditioner requires positive data and 3D volume shapes")
    if isinstance(diagonal_shift, int | float) and (
        not math.isfinite(diagonal_shift) or diagonal_shift < 0
    ):
        raise ValueError("spectral preconditioner diagonal shift must be finite and nonnegative")
    key = jax.random.key(seed)
    spectral_shape = (*volume_shape[:-1], volume_shape[-1] // 2 + 1)
    initial = jnp.zeros(spectral_shape, jnp.float32)

    def add_probe(index: jax.Array, total: jax.Array) -> jax.Array:
        data = jax.random.rademacher(jax.random.fold_in(key, index), data_shape, dtype=jnp.float32)
        volume = adjoint(data)
        if volume.shape != volume_shape or volume.dtype != jnp.float32:
            raise ValueError(
                "spectral preconditioner adjoint must return the real volume shape in FP32"
            )
        transformed = jnp.fft.rfftn(volume)
        power = jnp.real(transformed * jnp.conj(transformed))
        return total + power

    spectrum = jax.lax.fori_loop(0, probes, add_probe, initial) / (probes * math.prod(volume_shape))
    spectrum = spectrum + diagonal_shift
    maximum = jnp.max(spectrum)
    floor = jnp.where(maximum > 0, maximum * jnp.finfo(jnp.float32).eps, 1)
    return jnp.maximum(spectrum, floor)


def apply_spectral_inverse(volume: jax.Array, spectrum: jax.Array) -> jax.Array:
    """Apply the real symmetric positive Fourier inverse with the original shape."""
    return jnp.fft.irfftn(jnp.fft.rfftn(volume) / spectrum, s=volume.shape)
