"""Laminography geometry helpers for tilted-axis parallel-beam scans."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

import numpy as np

from .base import Detector, Grid, PoseMatrix, RayPair, _parallel_detector_rays
from .transforms import align_u_to_v, rot_axis_angle

if TYPE_CHECKING:
    from collections.abc import Sequence


def laminography_tilt_matrix(tilt_deg: float, tilt_about: str) -> np.ndarray:
    """Return the fixed rotation that tilts the nominal tomography axis."""
    tilt = float(np.deg2rad(tilt_deg))
    if abs(tilt) < 1e-12:
        return np.eye(3, dtype=np.float64)
    if tilt_about == "x":
        c, s = np.cos(tilt), np.sin(tilt)
        return np.array([[1.0, 0.0, 0.0], [0.0, c, s], [0.0, -s, c]], dtype=np.float64)
    if tilt_about == "z":
        c, s = np.cos(tilt), np.sin(tilt)
        return np.array([[c, 0.0, s], [0.0, 1.0, 0.0], [-s, 0.0, c]], dtype=np.float64)
    raise ValueError("tilt_about must be 'x' or 'z'")


def laminography_axis_unit(tilt_deg: float, tilt_about: str) -> np.ndarray:
    """Return the unit rotation axis implied by the laminography tilt."""
    R_tilt = laminography_tilt_matrix(tilt_deg, tilt_about)
    ax = R_tilt @ np.array([0.0, 0.0, 1.0], dtype=np.float64)
    return ax / (np.linalg.norm(ax) + 1e-12)


@dataclass
class LaminographyGeometry:
    """Laminography geometry with tilted rotation axis (parallel-ray model).

    - Beam direction is fixed along +y (as in ParallelGeometry).
    - Rotation axis is tilted away from +z by `tilt_deg` within a chosen plane.
      With `tilt_about='x'` the axis leans towards +y (beam-aligned laminography);
      with `tilt_about='z'` the axis leans towards +x. Each view rotates the
      object around this axis by angle `thetas_deg[i]`.

    Frame convention:
    - pose_for_view(i) returns T_world_from_obj for the sample frame, where the
      object's +z axis equals the nominal rotation axis. At theta=0, T is the
      fixed alignment S (generally not identity) that maps e_z -> axis.
    """

    grid: Grid
    detector: Detector
    thetas_deg: Sequence[float]
    tilt_deg: float = 30.0
    tilt_about: str = "x"  # or "z"

    def _tilt_matrix(self) -> np.ndarray:
        return laminography_tilt_matrix(self.tilt_deg, self.tilt_about)

    def _axis_unit(self) -> np.ndarray:
        return laminography_axis_unit(self.tilt_deg, self.tilt_about)

    def pose_for_view(self, i: int) -> PoseMatrix:
        """World-from-object pose in sample frame; rotation about object +z.

        We align the object's +z axis to the laminography axis once via S, then
        rotate around +z by view angle theta: R = S @ R_z(theta). The returned
        4x4 poses are suitable for the projector contract (world_from_object).
        """
        theta = float(np.deg2rad(self.thetas_deg[i]))
        axis = self._axis_unit()
        ez = np.array([0.0, 0.0, 1.0], dtype=np.float64)
        S = align_u_to_v(ez, axis)
        Rz = rot_axis_angle(ez, theta)[:3, :3]
        R = S @ Rz
        T = np.eye(4, dtype=np.float64)
        T[:3, :3] = R
        return tuple(map(tuple, T))  # 4x4

    def rays_for_view(self, i: int) -> RayPair:
        """Return detector ray callbacks for inspection tools."""
        del i
        # Use the same detector plane and beam direction as parallel CT.
        return _parallel_detector_rays(self.grid, self.detector)
