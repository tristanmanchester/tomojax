"""Lightweight HDF5/NXtomo inspection helpers owned by the IO boundary."""

from __future__ import annotations

from collections.abc import Iterator
import json
import math
from pathlib import Path
from typing import Any, cast

import h5py
import numpy as np
from numpy.typing import NDArray

from tomojax._typed_arrays import (
    any_true,
    finite_values_float64,
    linspace_indices,
    max_float,
    min_float,
    numpy_array,
    numpy_float64_array,
    numpy_int64_array,
    object_list,
    object_mapping,
    scalar_float,
    scalar_int,
    sum_float64,
    true_count,
    unique_int_count_map,
)
from tomojax.io._inspection_types import (
    AlignmentReport,
    AnglesReport,
    DetectorMetadataReport,
    FlatsDarksReport,
    GeometryReport,
    InspectionReport,
    MemoryEstimatesReport,
    NonfiniteReport,
    PreprocessReport,
    ProjectionReport,
    ProjectionStatsReport,
    WorkingSetEstimate,
)

type PathLike = str | Path


_PROJECTION_PATHS = (
    "/entry/instrument/detector/data",
    "/entry/data/projections",
    "/entry/projections",
)
_ANGLE_PATH = "/entry/sample/transformations/rotation_angle"
_IMAGE_KEY_PATH = "/entry/instrument/detector/image_key"
_ALIGN_PATH = "/entry/processing/tomojax/align"
_DEFAULT_MAX_EXACT_STATS_ELEMENTS = 5_000_000
_MAX_PERCENTILE_SAMPLE_ELEMENTS = 1_000_000


def _attr_to_str(value: object, default: str | None = None) -> str | None:
    if value is None:
        return default
    try:
        if isinstance(value, bytes):
            return value.decode("utf-8", errors="ignore")
        if isinstance(value, np.ndarray):
            array = numpy_array(cast("object", value))
            if array.shape == ():
                return _attr_to_str(cast("object", array.item()), default)
            if array.size >= 1:
                return _attr_to_str(cast("object", array.flat[0]), default)
        return str(cast("object", value))
    except (TypeError, UnicodeDecodeError, ValueError):
        return default


def _json_attr_to_mapping(value: object) -> dict[str, Any] | None:
    text = _attr_to_str(value)
    if not text:
        return None
    try:
        parsed = cast("object", json.loads(text))
    except (json.JSONDecodeError, TypeError):
        return None
    return object_mapping(cast("object", parsed)) if isinstance(parsed, dict) else None


def _json_safe(value: object) -> object:
    if isinstance(value, np.generic):
        return cast("object", value.item())
    if isinstance(value, np.ndarray):
        return [_json_safe(item) for item in object_list(cast("object", value.tolist()))]
    if isinstance(value, dict):
        return {
            key: _json_safe(item) for key, item in object_mapping(cast("object", value)).items()
        }
    if isinstance(value, list | tuple):
        return [_json_safe(item) for item in object_list(cast("object", value))]
    return value


def _dataset_at(file: h5py.File, path: str) -> h5py.Dataset | None:
    obj = file.get(path)
    return obj if isinstance(obj, h5py.Dataset) else None


def _find_projection_dataset(file: h5py.File) -> tuple[str | None, h5py.Dataset | None]:
    for path in _PROJECTION_PATHS:
        dataset = _dataset_at(file, path)
        if dataset is not None:
            return path, dataset
    return None, None


def _iter_view_blocks(dataset: h5py.Dataset) -> Iterator[NDArray[np.float64]]:
    n_views = int(dataset.shape[0])
    block = 1
    if dataset.ndim == 3:
        plane_elements = max(1, int(dataset.shape[1]) * int(dataset.shape[2]))
        block = max(1, min(n_views, _DEFAULT_MAX_EXACT_STATS_ELEMENTS // plane_elements))
    for start in range(0, n_views, block):
        stop = min(n_views, start + block)
        yield numpy_float64_array(dataset[start:stop])


def _sample_projection_values(dataset: h5py.Dataset) -> NDArray[np.float64]:
    total = int(dataset.size or 0)
    if total <= _MAX_PERCENTILE_SAMPLE_ELEMENTS:
        return numpy_float64_array(dataset[...]).ravel()

    n_views = int(dataset.shape[0])
    plane_elements = max(1, total // max(1, n_views))
    n_sample_views = max(1, min(n_views, _MAX_PERCENTILE_SAMPLE_ELEMENTS // plane_elements))
    view_indices = linspace_indices(0, n_views - 1, num=n_sample_views)
    samples: list[NDArray[np.float64]] = [
        numpy_float64_array(dataset[index]).ravel() for index in view_indices
    ]
    if not samples:
        return np.asarray([], dtype=np.float64)
    return cast("NDArray[np.float64]", np.concatenate(samples))


def projection_stats(dataset: h5py.Dataset) -> tuple[ProjectionStatsReport, NonfiniteReport]:
    """Return finite-value projection statistics and nonfinite counts for an HDF5 dataset."""
    finite_count = 0
    finite_sum = 0.0
    finite_min = math.inf
    finite_max = -math.inf
    nan_count = 0
    posinf_count = 0
    neginf_count = 0

    for block in _iter_view_blocks(dataset):
        arr = numpy_float64_array(block)
        nan_count += true_count(np.isnan(arr))
        posinf_count += true_count(np.isposinf(arr))
        neginf_count += true_count(np.isneginf(arr))
        finite = np.isfinite(arr)
        if any_true(finite):
            values = finite_values_float64(arr, finite)
            finite_count += int(values.size)
            finite_sum += sum_float64(values)
            finite_min = min(finite_min, min_float(values))
            finite_max = max(finite_max, max_float(values))

    sample = _sample_projection_values(dataset)
    sample_finite = finite_values_float64(sample, np.isfinite(sample))
    if finite_count == 0:
        stats: ProjectionStatsReport = {
            "min": None,
            "p01": None,
            "mean": None,
            "p50": None,
            "p99": None,
            "max": None,
        }
    else:
        if sample_finite.size == 0:
            p01 = None
            p50 = None
            p99 = None
        else:
            percentiles = numpy_float64_array(np.percentile(sample_finite, [1.0, 50.0, 99.0]))
            p01 = scalar_float(cast("object", percentiles[0]))
            p50 = scalar_float(cast("object", percentiles[1]))
            p99 = scalar_float(cast("object", percentiles[2]))
        stats = {
            "min": float(finite_min),
            "p01": p01,
            "mean": float(finite_sum / finite_count),
            "p50": p50,
            "p99": p99,
            "max": float(finite_max),
        }

    nonfinite: NonfiniteReport = {
        "nan_count": int(nan_count),
        "posinf_count": int(posinf_count),
        "neginf_count": int(neginf_count),
        "inf_count": int(posinf_count + neginf_count),
    }
    return stats, nonfinite


def _projection_report(path: str | None, dataset: h5py.Dataset | None) -> ProjectionReport:
    if dataset is None:
        return {
            "found": False,
            "path": None,
            "shape": None,
            "dtype": None,
            "n_views": None,
            "detector_shape": None,
            "storage_bytes": None,
            "stats": {
                "min": None,
                "p01": None,
                "mean": None,
                "p50": None,
                "p99": None,
                "max": None,
            },
            "nonfinite": {
                "nan_count": None,
                "posinf_count": None,
                "neginf_count": None,
                "inf_count": None,
            },
        }
    if dataset.ndim != 3:
        raise ValueError(f"projection dataset must be 3D (n_views, nv, nu), got {dataset.shape}")

    stats, nonfinite = projection_stats(dataset)
    n_views, nv, nu = (int(v) for v in dataset.shape)
    return {
        "found": True,
        "path": path,
        "shape": [n_views, nv, nu],
        "dtype": str(dataset.dtype),
        "n_views": n_views,
        "detector_shape": {"nv": nv, "nu": nu},
        "storage_bytes": int(int(dataset.size or 0) * dataset.dtype.itemsize),
        "stats": stats,
        "nonfinite": nonfinite,
    }


def _angles_report(file: h5py.File) -> AnglesReport:
    dataset = _dataset_at(file, _ANGLE_PATH)
    if dataset is None:
        return {
            "found": False,
            "path": None,
            "count": None,
            "units": None,
            "min_deg": None,
            "max_deg": None,
            "coverage_deg": None,
        }

    values = numpy_float64_array(dataset[...]).ravel()
    finite = values[np.isfinite(values)]
    units = _attr_to_str(dataset.attrs.get("units"))
    if finite.size == 0:
        min_deg = max_deg = coverage_deg = None
    else:
        min_deg = scalar_float(cast("object", finite.min()))
        max_deg = scalar_float(cast("object", finite.max()))
        coverage_deg = float(max_deg - min_deg)
    return {
        "found": True,
        "path": _ANGLE_PATH,
        "count": int(values.size),
        "units": units,
        "min_deg": min_deg,
        "max_deg": max_deg,
        "coverage_deg": coverage_deg,
    }


def _geometry_report(file: h5py.File) -> GeometryReport:
    geom = file.get("/entry/geometry")
    found = isinstance(geom, h5py.Group) and "type" in geom.attrs
    meta = None
    if isinstance(geom, h5py.Group):
        meta = _json_attr_to_mapping(geom.attrs.get("geometry_meta_json"))
    return {
        "found": bool(found),
        "type": _attr_to_str(geom.attrs.get("type"))
        if found and isinstance(geom, h5py.Group)
        else None,
        "meta_found": meta is not None,
        "meta_keys": sorted(str(k) for k in meta) if meta is not None else [],
    }


def _detector_metadata_report(file: h5py.File) -> DetectorMetadataReport:
    detector = file.get("/entry/instrument/detector")
    meta = (
        _json_attr_to_mapping(detector.attrs.get("detector_meta_json"))
        if isinstance(detector, h5py.Group)
        else None
    )
    if meta is None:
        return {
            "found": False,
            "nu": None,
            "nv": None,
            "du": None,
            "dv": None,
            "det_center": None,
        }
    return {
        "found": True,
        "nu": _json_safe(meta.get("nu")),
        "nv": _json_safe(meta.get("nv")),
        "du": _json_safe(meta.get("du")),
        "dv": _json_safe(meta.get("dv")),
        "det_center": _json_safe(meta.get("det_center")),
    }


def _flats_darks_report(file: h5py.File) -> FlatsDarksReport:
    dataset = _dataset_at(file, _IMAGE_KEY_PATH)
    if dataset is None:
        return {
            "image_key_found": False,
            "image_key_path": None,
            "image_key_counts": {},
            "sample_count": 0,
            "flats_present": False,
            "darks_present": False,
            "flat_count": 0,
            "dark_count": 0,
        }
    keys = numpy_int64_array(dataset[...]).ravel()
    count_map = unique_int_count_map(keys)
    sample_count = int(count_map.get("0", 0))
    flat_count = int(count_map.get("1", 0))
    dark_count = int(count_map.get("2", 0))
    return {
        "image_key_found": True,
        "image_key_path": _IMAGE_KEY_PATH,
        "image_key_counts": count_map,
        "sample_count": sample_count,
        "flats_present": flat_count > 0,
        "darks_present": dark_count > 0,
        "flat_count": flat_count,
        "dark_count": dark_count,
    }


def _preprocess_report(file: h5py.File) -> PreprocessReport:
    group = file.get("/entry/processing/tomojax/preprocess")
    if not isinstance(group, h5py.Group):
        return {
            "found": False,
            "output_domain": None,
            "formula": None,
            "epsilon": None,
            "clip_min": None,
            "paths": {},
            "overrides": {},
            "crop_bounds": None,
        }
    attrs = group.attrs
    paths: dict[str, str] = {}
    for key in (
        "input_path",
        "data_path",
        "projection_path",
        "flat_path",
        "dark_path",
        "angles_path",
        "image_key_path",
    ):
        value = _attr_to_str(attrs.get(key))
        if value and value != "null":
            paths[key] = value
    overrides = {
        "dark_override_used": _attr_to_str(attrs.get("dark_override_used")),
        "flat_override_used": _attr_to_str(attrs.get("flat_override_used")),
        "assume_dark_field": _attr_to_str(attrs.get("assume_dark_field")),
        "assume_flat_field": _attr_to_str(attrs.get("assume_flat_field")),
    }
    return {
        "found": True,
        "output_domain": _attr_to_str(attrs.get("output_domain")),
        "formula": _attr_to_str(attrs.get("correction_formula")),
        "epsilon": _attr_to_str(attrs.get("epsilon")),
        "clip_min": _attr_to_str(attrs.get("clip_min")),
        "paths": paths,
        "overrides": overrides,
        "crop_bounds": _json_attr_to_mapping(attrs.get("crop_bounds")),
    }


def _alignment_report(file: h5py.File) -> AlignmentReport:
    align = file.get(_ALIGN_PATH)
    if not isinstance(align, h5py.Group):
        return {
            "found": False,
            "params_found": False,
            "params_shape": None,
            "angle_offset_found": False,
            "angle_offset_shape": None,
            "misalign_spec_found": False,
            "gauge_fix_found": False,
        }
    params = align.get("thetas")
    angle_offset = align.get("angle_offset_deg")
    misalign_spec = _json_attr_to_mapping(align.attrs.get("misalign_spec_json"))
    gauge_fix = _json_attr_to_mapping(align.attrs.get("gauge_fix_json"))
    params_found = isinstance(params, h5py.Dataset)
    angle_offset_found = isinstance(angle_offset, h5py.Dataset)
    return {
        "found": bool(
            params_found or angle_offset_found or misalign_spec is not None or gauge_fix is not None
        ),
        "params_found": bool(params_found),
        "params_shape": [int(v) for v in params.shape] if params_found else None,
        "angle_offset_found": bool(angle_offset_found),
        "angle_offset_shape": [int(v) for v in angle_offset.shape] if angle_offset_found else None,
        "misalign_spec_found": misalign_spec is not None,
        "gauge_fix_found": gauge_fix is not None,
    }


def _grid_shape_from_metadata(file: h5py.File, projection: ProjectionReport) -> list[int] | None:
    entry = file.get("/entry")
    grid = (
        _json_attr_to_mapping(entry.attrs.get("grid_meta_json"))
        if isinstance(entry, h5py.Group)
        else None
    )
    if grid is not None:
        try:
            return [
                scalar_int(cast("object", grid["nx"])),
                scalar_int(cast("object", grid["ny"])),
                scalar_int(cast("object", grid["nz"])),
            ]
        except (KeyError, TypeError, ValueError):
            pass

    det_shape = projection.get("detector_shape")
    if isinstance(det_shape, dict):
        nu = det_shape.get("nu")
        nv = det_shape.get("nv")
        if nu is not None and nv is not None:
            return [int(nu), int(nu), int(nv)]
    return None


def _memory_estimates(file: h5py.File, projection: ProjectionReport) -> MemoryEstimatesReport:
    if not projection.get("found"):
        return {
            "feasible": False,
            "reconstruction_grid_shape": None,
            "input_projection_bytes": None,
            "modes": {},
            "notes": "Projection data not found; memory estimates are unavailable.",
        }

    grid_shape = _grid_shape_from_metadata(file, projection)
    projection_bytes = int(projection["storage_bytes"] or 0)
    if grid_shape is None:
        return {
            "feasible": False,
            "reconstruction_grid_shape": None,
            "input_projection_bytes": projection_bytes,
            "modes": {},
            "notes": "Could not infer reconstruction grid shape.",
        }

    voxels = int(grid_shape[0]) * int(grid_shape[1]) * int(grid_shape[2])
    volume_bytes = voxels * np.dtype(np.float32).itemsize
    modes: dict[str, WorkingSetEstimate] = {
        "fbp_fp32": {
            "estimated_working_set_bytes": int(projection_bytes + 2 * volume_bytes),
        },
        "fista_tv_fp32": {
            "estimated_working_set_bytes": int(projection_bytes + 5 * volume_bytes),
        },
        "spdhg_tv_fp32": {
            "estimated_working_set_bytes": int(projection_bytes + 5 * volume_bytes),
        },
    }
    return {
        "feasible": True,
        "reconstruction_grid_shape": grid_shape,
        "input_projection_bytes": projection_bytes,
        "modes": modes,
        "notes": "Heuristic fp32 working-set estimates; actual JAX/XLA peak memory may differ.",
    }


def inspect_nxtomo(path: PathLike) -> InspectionReport:
    """Inspect an HDF5/NXtomo file without materializing TomoJAX/JAX objects."""
    input_path = Path(path)
    with h5py.File(input_path, "r") as file:
        projection_path, projection_dataset = _find_projection_dataset(file)
        if projection_dataset is None:
            raise KeyError("Could not find projections dataset under /entry")
        projection = _projection_report(projection_path, projection_dataset)
        report: InspectionReport = {
            "schema_version": 1,
            "input_path": str(input_path),
            "projection": projection,
            "angles": _angles_report(file),
            "geometry": _geometry_report(file),
            "detector_metadata": _detector_metadata_report(file),
            "flats_darks": _flats_darks_report(file),
            "preprocess": _preprocess_report(file),
            "alignment": _alignment_report(file),
            "memory_estimates": _memory_estimates(file, projection),
        }
    return report


def inspect_dataset(path: PathLike) -> InspectionReport:
    """Inspect a measured projection dataset before reconstruction."""
    return inspect_nxtomo(Path(path))


__all__ = [
    "AlignmentReport",
    "AnglesReport",
    "DetectorMetadataReport",
    "FlatsDarksReport",
    "GeometryReport",
    "InspectionReport",
    "MemoryEstimatesReport",
    "NonfiniteReport",
    "PreprocessReport",
    "ProjectionReport",
    "ProjectionStatsReport",
    "WorkingSetEstimate",
    "inspect_dataset",
    "inspect_nxtomo",
    "projection_stats",
]
