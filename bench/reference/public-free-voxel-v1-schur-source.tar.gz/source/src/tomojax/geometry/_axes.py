"""Utilities for reconciling internal (xyz) and disk (zyx) axis orders."""

from __future__ import annotations

from typing import TYPE_CHECKING, cast, overload

import numpy as np

from tomojax.core.geometry.base import Grid, GridDict

if TYPE_CHECKING:
    from collections.abc import Sequence

try:  # pragma: no cover - JAX might be absent in build docs
    import jax  # type: ignore
    import jax.numpy as jnp  # type: ignore

    _jax_array_types = (jax.Array,)  # type: ignore[attr-defined]
except Exception:  # pragma: no cover - non-JAX contexts
    jax = None  # type: ignore[assignment]
    jnp = None  # type: ignore[assignment]
    _jax_array_types: tuple[type[object], ...] = ()

_JAX_ARRAY_TYPES = _jax_array_types


INTERNAL_VOLUME_AXES = "xyz"
DISK_VOLUME_AXES = "zyx"
VOLUME_AXES_ATTR = "volume_axes_order"
CORE_X_AXIS = 0
CORE_Y_AXIS = 1
CORE_Z_AXIS = 2
DET_U_VOLUME_AXIS = CORE_X_AXIS
DET_V_VOLUME_AXIS = CORE_Z_AXIS
TOMO_ROTATION_PLANE_AXES = (CORE_X_AXIS, CORE_Y_AXIS)
TOMO_AXIS = CORE_Z_AXIS
GridLike = Grid | GridDict


def _norm_axes(axes: str) -> str:
    axes = axes.lower()
    if len(axes) != 3:
        raise ValueError(f"axes '{axes}' must be length 3")
    if set(axes) != {"x", "y", "z"}:
        raise ValueError(f"axes '{axes}' must be a permutation of xyz")
    return axes


def axes_to_perm(src: str, dst: str) -> tuple[int, int, int]:
    """Return permutation bringing `src` axis order into `dst` order."""
    s = _norm_axes(src)
    d = _norm_axes(dst)
    return cast("tuple[int, int, int]", tuple(s.index(axis) for axis in d))


@overload
def transpose_volume(volume: np.ndarray, src: str, dst: str) -> np.ndarray: ...


@overload
def transpose_volume(volume: object, src: str, dst: str) -> object: ...


def transpose_volume(volume: object, src: str, dst: str) -> object:
    """Transpose a volume from `src` axis order to `dst` order.

    Keeps numpy arrays as numpy and JAX arrays as JAX when possible.
    """
    perm = axes_to_perm(src, dst)

    if _JAX_ARRAY_TYPES and isinstance(
        volume,
        _JAX_ARRAY_TYPES,
    ):  # pragma: no cover - exercised in GPU envs
        if jnp is None:
            raise RuntimeError("JAX array transpose requested but jax.numpy is unavailable")
        if perm == (0, 1, 2):
            return volume
        return cast("object", jnp.transpose(volume, axes=perm))

    if isinstance(volume, np.ndarray):
        if perm == (0, 1, 2):
            return cast("object", volume)
        return cast("object", volume.transpose(perm))

    arr = np.asarray(volume)
    if perm == (0, 1, 2):
        return cast("object", arr)
    return cast("object", np.transpose(arr, axes=perm))


def _grid_dims(grid: GridLike | None) -> tuple[int, int, int] | None:
    if grid is None:
        return None
    if hasattr(grid, "nx") and hasattr(grid, "ny") and hasattr(grid, "nz"):
        try:
            return (int(grid.nx), int(grid.ny), int(grid.nz))  # type: ignore[attr-defined]
        except Exception:  # pragma: no cover - defensive
            return None
    if isinstance(grid, dict):
        try:
            return (int(grid["nx"]), int(grid["ny"]), int(grid["nz"]))
        except Exception:
            return None
    return None


def is_shape_xyz(vol_shape: Sequence[int], grid: GridLike | None) -> bool:
    dims = _grid_dims(grid)
    if dims is None:
        return False
    if len(vol_shape) != 3:
        return False
    return tuple(int(s) for s in vol_shape) == dims


def is_shape_zyx(vol_shape: Sequence[int], grid: GridLike | None) -> bool:
    dims = _grid_dims(grid)
    if dims is None:
        return False
    if len(vol_shape) != 3:
        return False
    return tuple(int(s) for s in vol_shape) == (dims[2], dims[1], dims[0])


def infer_disk_axes(vol_shape: Sequence[int], grid: GridLike | None) -> str | None:
    """Infer on-disk axis order using grid heuristics.

    Returns "xyz", "zyx", or None if ambiguous.
    """
    if len(vol_shape) != 3:
        return None
    matches_xyz = is_shape_xyz(vol_shape, grid)
    matches_zyx = is_shape_zyx(vol_shape, grid)
    if matches_xyz and matches_zyx:
        return None
    if matches_xyz:
        return INTERNAL_VOLUME_AXES
    if matches_zyx:
        return DISK_VOLUME_AXES
    # Without grid metadata, inferring axis order from shape alone is unreliable.
    return None


__all__ = [
    "CORE_X_AXIS",
    "CORE_Y_AXIS",
    "CORE_Z_AXIS",
    "DET_U_VOLUME_AXIS",
    "DET_V_VOLUME_AXIS",
    "DISK_VOLUME_AXES",
    "INTERNAL_VOLUME_AXES",
    "TOMO_AXIS",
    "TOMO_ROTATION_PLANE_AXES",
    "VOLUME_AXES_ATTR",
    "axes_to_perm",
    "infer_disk_axes",
    "is_shape_xyz",
    "is_shape_zyx",
    "transpose_volume",
]
