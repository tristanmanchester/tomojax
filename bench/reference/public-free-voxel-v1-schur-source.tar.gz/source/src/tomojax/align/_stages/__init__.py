"""Multiresolution stage orchestration internals."""
