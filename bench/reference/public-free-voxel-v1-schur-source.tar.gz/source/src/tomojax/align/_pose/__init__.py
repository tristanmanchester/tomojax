"""Pose alignment internals."""
