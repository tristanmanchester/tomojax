"""Synthetic dataset implementation modules."""
