from __future__ import annotations

import importlib
import os
from pathlib import Path
import re
import subprocess
import sys

import pytest


def test_public_facades_import_cleanly() -> None:
    modules = (
        "tomojax",
        "tomojax.align",
        "tomojax.align.api",
        "tomojax.backends",
        "tomojax.cli",
        "tomojax.datasets",
        "tomojax.forward",
        "tomojax.geometry",
        "tomojax.io",
        "tomojax.motion",
        "tomojax.nuisance",
        "tomojax.recon",
    )
    for module_name in modules:
        assert importlib.import_module(module_name) is not None


def test_cli_imports_do_not_configure_jax_allocator(monkeypatch: pytest.MonkeyPatch) -> None:
    for name in ("XLA_PYTHON_CLIENT_PREALLOCATE", "XLA_PYTHON_CLIENT_ALLOCATOR"):
        monkeypatch.delenv(name, raising=False)

    for module_name in (
        "tomojax.cli.main",
        "tomojax.cli.recon",
        "tomojax.cli.simulate",
        "tomojax.cli.align",
    ):
        module = importlib.import_module(module_name)
        importlib.reload(module)

    assert "XLA_PYTHON_CLIENT_PREALLOCATE" not in os.environ
    assert "XLA_PYTHON_CLIENT_ALLOCATOR" not in os.environ


def test_non_product_namespaces_are_absent() -> None:
    for module_name in ("tomojax.bench", "tomojax.verify", "tomojax.data"):
        with pytest.raises(ModuleNotFoundError):
            importlib.import_module(module_name)


def test_io_root_surface_is_smaller_than_full_api() -> None:
    import tomojax.io as io_root
    import tomojax.io.api as io_api

    assert len(io_root.__all__) < len(io_api.__all__)
    assert "load_dataset" in io_root.__all__
    assert "preprocess_nxtomo" in io_root.__all__
    assert "inspect_dataset" not in io_root.__all__
    assert "flat_dark_to_absorption" not in io_root.__all__


def test_cli_catalog_is_product_only(capsys: pytest.CaptureFixture[str]) -> None:
    from tomojax.cli import PRODUCT_COMMANDS, product_command_names
    from tomojax.cli.main import main

    assert product_command_names() == (
        "inspect",
        "validate",
        "preprocess",
        "ingest",
        "convert",
        "recon",
        "slices",
        "align",
        "simulate",
    )
    assert all(command.name in product_command_names() for command in PRODUCT_COMMANDS)
    assert main(["--help"]) == 0
    captured = capsys.readouterr()
    assert "tomojax inspect scan.nxs" in captured.out
    assert "dev" not in captured.out.lower()
    assert "benchmark" not in captured.out.lower()

    with pytest.raises(SystemExit) as exc_info:
        main(["dev", "--help"])
    assert exc_info.value.code == 2


def test_product_command_help_has_no_dev_story(capsys: pytest.CaptureFixture[str]) -> None:
    from tomojax.cli.main import main

    for command in (
        "inspect",
        "validate",
        "preprocess",
        "ingest",
        "convert",
        "recon",
        "slices",
        "align",
        "simulate",
    ):
        with pytest.raises(SystemExit) as exc_info:
            main([command, "--help"])

        assert exc_info.value.code == 0
        captured = capsys.readouterr()
        lowered = captured.out.lower()
        assert "diagnostic" not in lowered
        assert "benchmark" not in lowered
        assert "v" + "1" not in lowered
        assert "par" + "ity" not in lowered
        if command == "simulate":
            assert "--noise" not in captured.out
            assert "--noise-level" not in captured.out


def test_root_docs_do_not_advertise_removed_package_surfaces() -> None:
    root = Path(__file__).resolve().parents[1]
    docs = [root / "README.md", *sorted((root / "docs").glob("*.md"))]
    public_docs = "\n".join(path.read_text(encoding="utf-8") for path in docs)
    assert re.search(r"tomojax\.data(?!sets)\b", public_docs) is None
    assert re.search(r"tomojax\.bench\b", public_docs) is None
    assert re.search(r"tomojax\.verify\b", public_docs) is None
    # Guard actual removed entrypoints. Ordinary words such as compatibility
    # and parity also belong in dependency and numerical comparison guidance.
    assert re.search(r"tomojax\s+(?:bench|verify)\b", public_docs) is None


def test_private_import_guard_blocks_tests_from_internal_data_namespace(tmp_path: Path) -> None:
    root = Path(__file__).resolve().parents[1]
    bad_test = tmp_path / "test_bad_data_import.py"
    bad_test.write_text("from tomojax._data.phantoms import make_phantom\n", encoding="utf-8")

    result = subprocess.run(
        [sys.executable, "tools/check_public_imports.py", str(bad_test)],
        cwd=root,
        check=False,
        text=True,
        capture_output=True,
    )

    assert result.returncode == 1
    assert "private data implementation" in result.stderr


def test_private_import_guard_expands_root_package_from_imports(tmp_path: Path) -> None:
    root = Path(__file__).resolve().parents[1]
    bad_test = tmp_path / "test_bad_root_import.py"
    bad_test.write_text("from tomojax import _data\n", encoding="utf-8")

    result = subprocess.run(
        [sys.executable, "tools/check_public_imports.py", str(bad_test)],
        cwd=root,
        check=False,
        text=True,
        capture_output=True,
    )

    assert result.returncode == 1
    assert "private data implementation" in result.stderr
    assert "imports tomojax._data" in result.stderr


def test_private_import_guard_passes_on_product_tree() -> None:
    root = Path(__file__).resolve().parents[1]
    result = subprocess.run(
        [sys.executable, "tools/check_public_imports.py"],
        cwd=root,
        check=False,
        text=True,
        capture_output=True,
    )
    assert result.returncode == 0, result.stderr
