"""Refresh the entire frozen reconstruction matrix before system-level changes.

No solver policy is selected from phantom truth. All candidate algorithms use
the existing frozen budget search and independent acceptance verifier. Failed
and unsupported records remain in the report.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tarfile

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--tag', default='whole-matrix-baseline-v2')
parser.add_argument('--source-root', type=Path, default=Path('.'))
args = parser.parse_args()
source_root = args.source_root.resolve()
base = Path('.artifacts/system-matrix')
tag = args.tag
assert tag and all(c.isalnum() or c in '-_' for c in tag)
output = base/f'{tag}.json'
assert not output.exists()
os.environ['XLA_PYTHON_CLIENT_PREALLOCATE'] = 'false'
os.environ['OPENBLAS_NUM_THREADS'] = '1'
paths = sorted([*(source_root/'src').rglob('*.py'), *(source_root/'bench').glob('*.py')])
paths.append(Path(__file__).resolve())
os.environ['PYTHONPATH'] = str(source_root/'src')


def digest():
    h = hashlib.sha256()
    for path in paths:
        h.update(str(path).encode()+b'\0'+path.read_bytes())
    return h.hexdigest()


source = digest()
with tarfile.open(base/f'{tag}-source.tar.gz', 'w:gz') as archive:
    for path in paths:
        archive.add(path, arcname=str(path.relative_to(source_root))
                    if path.is_relative_to(source_root) else 'driver.py')
methods = [
    'tomojax_fourier_cupy', 'tomojax_joseph_cgls_pallas',
    'tomojax_multires_joseph_cgls_pallas', 'tomojax_fbp_joseph_cgls_pallas',
    'astra_fbp3d_cupy', 'astra_fbp2d', 'astra_fbp_cgls', 'astra_cgls',
    'astra_sirt', 'tigre_fbp', 'tigre_cgls',
]
suites = ['gaussian-v1', 'structured-v1', 'structured-noisy-v1']
payload = dict(complete=False, source_sha256=source,
    source_root=str(source_root),
    primary='fresh-process time through first accepted result, including failed lower budgets',
    methods=methods, scheduled_cells=[
        dict(suite=suite, size=size, geometry=geometry, views=180)
        for suite in suites for size in [64, 128, 256]
        for geometry in ['parallel', 'anisotropic', 'lamino']],
    records=[])
output.write_text(json.dumps(payload, indent=2))
for suite in suites:
    target = base/f'{tag}-{suite}.json'
    log = base/f'{tag}-{suite}.log'
    assert not target.exists() and not log.exists()
    command = [sys.executable, str(source_root/'bench/compare_reconstructions.py'), '--suite', suite,
        '--sizes', '64', '128', '256', '--geometries', 'parallel', 'anisotropic', 'lamino',
        '--views', '180', '--batch', '180', '--repeats', '7', '--max-iters', '256',
        '--timeout', '1800', '--methods', *methods, '--output', str(target)]
    print('START', suite, flush=True)
    with log.open('w') as stream:
        result = subprocess.run(command, stdout=stream, stderr=subprocess.STDOUT)
    # Suite exit 1 can mean retained quality failures, not failed orchestration.
    record = dict(suite=suite, path=str(target), command=command,
                  exit_code=result.returncode, log=str(log))
    if target.exists():
        data = json.loads(target.read_text())
        record['record_count'] = len(data['records'])
        record['statuses'] = {status: sum(r['status'] == status for r in data['records'])
                              for status in sorted({r['status'] for r in data['records']})}
    payload['records'].append(record)
    output.write_text(json.dumps(payload, indent=2))
    print('DONE', suite, record.get('statuses'), flush=True)
assert digest() == source, 'source changed during baseline refresh'
payload['complete'] = all(r.get('record_count') == 9*len(methods) for r in payload['records'])
output.write_text(json.dumps(payload, indent=2))
print('baseline queue finished; complete', payload['complete'], 'source unchanged', flush=True)
